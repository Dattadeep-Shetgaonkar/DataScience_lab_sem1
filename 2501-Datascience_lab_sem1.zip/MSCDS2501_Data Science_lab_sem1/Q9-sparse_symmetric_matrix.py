# Function to check if the given input is a matrix
def is_matrix(a):
    if type(a) != list or len(a) == 0:
        return False
    for row in a:
        if type(row) != list:
            return False
    first = len(a[0])
    for row in a:
        if len(row) != first:
            return False
    return True


#  sparse
def is_sparse_matrix(mat):
    if not is_matrix(mat):
        return "Not a valid matrix"
    
    total = len(mat) * len(mat[0])
    zeros = 0
    for i in mat:
        for j in i:
            if j == 0:
                zeros += 1
    if zeros > total / 2:
        return True
    else:
        return False


# Function to get non-zero elements as lists of rows, cols, and values
def get_non_zero_components(mat):
    if not is_matrix(mat):
        return "Not a valid matrix"

    row_pos = []
    col_pos = []
    val = []

    for i in range(len(mat)):
        for j in range(len(mat[0])):
            if mat[i][j] != 0:
                row_pos.append(i)
                col_pos.append(j)
                val.append(mat[i][j])
    return [row_pos, col_pos, val]


# symmetric
def is_symmetric_matrix(mat):
    if not is_matrix(mat):
        return "Not a valid matrix"
    
    r = len(mat)
    c = len(mat[0])
    if r != c:
        return False
    
    for i in range(r):
        for j in range(c):
            if mat[i][j] != mat[j][i]:
                return False
    return True


# Example matrix
matrix1 = [
    [0, 4, 0],
    [4, 0, 6],
    [0, 6, 0]
]

print("Matrix:", matrix1)
print("Is matrix sparse ", is_sparse_matrix(matrix1))
print("Is matrix symmetric ", is_symmetric_matrix(matrix1))

res = get_non_zero_components(matrix1)
print("Non-zero entries are:")
print("Rows:", res[0])
print("Cols:", res[1])
print("Values:", res[2])
